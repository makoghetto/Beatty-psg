# Golden Fiesta Photo Booth

## Setup

1. Create a Google Drive folder named `Golden Fiesta Photos`.
2. Create a Google Sheet with headers:
   - ID
   - Filename
   - URL
   - Printed
3. Open https://script.google.com and create a new Apps Script project.
4. Replace the default Code.gs with the supplied `Code.gs`.
5. Replace `DRIVE_FOLDER_ID` with your Google Drive folder ID.
6. Replace `SHEET_ID` with your Google Sheet ID.
7. Deploy:
   - Deploy → New deployment
   - Type: Web app
   - Execute as: Me
   - Who has access: Anyone
   - Copy the Web App URL.
8. In `upload.html` and `gallery.html`, replace:
   `PASTE_YOUR_APPS_SCRIPT_WEB_APP_URL_HERE`
   with the Web App URL.
9. Place your transparent overlay image in `/web/frame.png`.
10. Push the `/web` folder to a GitHub Pages repository.
11. Enable GitHub Pages (Settings → Pages → Deploy from branch).

Open:
- upload.html for taking photos.
- gallery.html for the print station.
